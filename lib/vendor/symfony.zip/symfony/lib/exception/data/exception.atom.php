<?php include sfException::getTemplatePathForError('xml', true) ?>
