<?php

/**
 * AuthorInheritanceConcrete form.
 *
 * @package    symfony12
 * @subpackage form
 * @author     Your name here
 * @version    SVN: $Id: AuthorInheritanceConcreteForm.class.php 22748 2009-10-02 23:19:37Z Kris.Wallsmith $
 */
class AuthorInheritanceConcreteForm extends BaseAuthorInheritanceConcreteForm
{
  /**
   * @see AuthorForm
   */
  public function configure()
  {
    parent::configure();
  }
}
