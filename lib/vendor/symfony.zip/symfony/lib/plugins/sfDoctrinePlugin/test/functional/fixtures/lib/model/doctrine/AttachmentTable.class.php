<?php

class AttachmentTable extends Doctrine_Table
{
}
