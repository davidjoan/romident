<?php

/**
 * UniqueTest form.
 *
 * @package    form
 * @subpackage UniqueTest
 * @version    SVN: $Id: UniqueTestForm.class.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class UniqueTestForm extends BaseUniqueTestForm
{
  public function configure()
  {
  }
}