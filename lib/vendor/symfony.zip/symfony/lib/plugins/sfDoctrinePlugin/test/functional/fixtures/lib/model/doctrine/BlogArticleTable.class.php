<?php

class BlogArticleTable extends ArticleTable
{
}
