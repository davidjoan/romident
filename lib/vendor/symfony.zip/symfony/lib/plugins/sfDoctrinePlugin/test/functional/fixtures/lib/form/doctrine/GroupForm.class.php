<?php

/**
 * Group form.
 *
 * @package    form
 * @subpackage Group
 * @version    SVN: $Id: GroupForm.class.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class GroupForm extends BaseGroupForm
{
  public function configure()
  {
  }
}