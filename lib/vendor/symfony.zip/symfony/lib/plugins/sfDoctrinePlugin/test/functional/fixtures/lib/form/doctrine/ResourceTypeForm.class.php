<?php

/**
 * ResourceType form.
 *
 * @package    symfony12
 * @subpackage form
 * @author     Your name here
 * @version    SVN: $Id: ResourceTypeForm.class.php 27742 2010-02-08 15:46:35Z Kris.Wallsmith $
 */
class ResourceTypeForm extends BaseResourceTypeForm
{
  public function configure()
  {
  }
}
