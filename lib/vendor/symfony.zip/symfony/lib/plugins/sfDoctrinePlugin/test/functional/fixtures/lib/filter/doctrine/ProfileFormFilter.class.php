<?php

/**
 * Profile filter form.
 *
 * @package    filters
 * @subpackage Profile *
 * @version    SVN: $Id: ProfileFormFilter.class.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class ProfileFormFilter extends BaseProfileFormFilter
{
  public function configure()
  {
  }
}