<?php

/**
 * Author filter form.
 *
 * @package    filters
 * @subpackage Author *
 * @version    SVN: $Id: AuthorFormFilter.class.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class AuthorFormFilter extends BaseAuthorFormFilter
{
  public function configure()
  {
  }
}