<?php

/**
 * Subscription form.
 *
 * @package    form
 * @subpackage Subscription
 * @version    SVN: $Id: SubscriptionForm.class.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class SubscriptionForm extends BaseSubscriptionForm
{
  public function configure()
  {
  }
}